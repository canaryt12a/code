﻿
using WebApplication3.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using WebApplication3.CommonHelpers;
using System.Web.Mvc;
using Newtonsoft.Json;
using System.Web.Script.Serialization;
// for File operation
using System.IO;

using Newtonsoft.Json.Linq;
using System.Web;



namespace WebApplication3.Controllers
{
    public class StudentsController : Controller
    
    {
        private static string strPath = "~/App_Data/dataStudent.json" ;
        private static List<Student> students = new List<Student> ();
         //   {


            /*new Student(){StudentID=10,StudentName="Hoang Yen",ClassId=1,Gender=false,BirthDay=new DateTime(1980, 8,  17)},
            new Student(){StudentID=11,StudentName="Tran Thanh Mai",ClassId=1,Gender=false,BirthDay=new DateTime(1980, 8,  10)},
            new Student(){StudentID=12,StudentName="Le Hoa",ClassId=1,Gender=true,BirthDay=new DateTime(1980, 8,  10)},
            new Student(){StudentID=13,StudentName="Tran Minh",ClassId=1,Gender=false,BirthDay=new DateTime(1980, 8,  11)},
            new Student(){StudentID=14,StudentName="Nga Hoang",ClassId=2,Gender=true,BirthDay=new DateTime(1980, 8,  11)},
            new Student(){StudentID=15,StudentName="Le THanh",ClassId=2,Gender=true,BirthDay=new DateTime(1981, 7,  17)},
            new Student(){StudentID=16,StudentName="Hong Hoa",ClassId=2,Gender=true,BirthDay=new DateTime(1981, 6,  17)},
            new Student(){StudentID=17,StudentName="Van Minh",ClassId=2,Gender=true,BirthDay=new DateTime(1981, 8,  17)},
            new Student(){StudentID=18,StudentName="Thang",ClassId=1,Gender=true,BirthDay= new DateTime(1981, 8,  17) },
            new Student(){StudentID=19,StudentName="Anna nguyen",ClassId=1,Gender=false,BirthDay=new DateTime(1981, 8, 17)}*/



      //  };
        //Get student list from json file
        private List<Student> GetDataStudent()
        {

            string file = HttpContext.Server.MapPath(strPath);
            //deserialize JSON from file  
            string json = System.IO.File.ReadAllText(file);
            JavaScriptSerializer ser = new JavaScriptSerializer();
            List<Student> personlist = ser.Deserialize<List<Student>>(json);
            return personlist;
    }

       

        public JsonResult Students()
        {
            students = GetDataStudent();
            return this.Jsonp(students);
        }


        public JsonpResult Update(string models)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            List<Student> updatedPros = serializer.Deserialize<List<Student>>(models);
            string output = Newtonsoft.Json.JsonConvert.SerializeObject(updatedPros, Newtonsoft.Json.Formatting.Indented);
            UpdateBackend(updatedPros);
            return this.Jsonp(updatedPros[0]);
            

        }
        public void UpdateBackend( List<Student> updatedPros)
        {
            string file = HttpContext.Server.MapPath(strPath);
        
            int Id = Convert.ToInt32(updatedPros[0].StudentID);

            foreach (var student in students.Where(obj => obj.StudentID == Id))
            {
                student.Gender = updatedPros[0].Gender;
                student.StudentName = updatedPros[0].StudentName;
                student.ClassId = updatedPros[0].ClassId;
                student.BirthDay = updatedPros[0].BirthDay;
            }

            string output = Newtonsoft.Json.JsonConvert.SerializeObject(students, Newtonsoft.Json.Formatting.Indented);
            System.IO.File.WriteAllText(file, output);
        }


        public JsonpResult Destroy(string models)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            List<Student> updatedPros = serializer.Deserialize<List<Student>>(models);
            string output = Newtonsoft.Json.JsonConvert.SerializeObject(updatedPros, Newtonsoft.Json.Formatting.Indented);
            DeleteBackend(updatedPros);
            return this.Jsonp(updatedPros[0]);


        }

        public void DeleteBackend(List<Student> updatedPros)
        {
            string file = HttpContext.Server.MapPath(strPath);

            int Id = Convert.ToInt32(updatedPros[0].StudentID);

            var studentToDeleted = students.FirstOrDefault(obj => obj.StudentID == Id);
            students.Remove(studentToDeleted);

            string output = Newtonsoft.Json.JsonConvert.SerializeObject(students, Newtonsoft.Json.Formatting.Indented);
            System.IO.File.WriteAllText(file, output);
        }


        public JsonpResult BindGridOnSearch1(string v)
        {

            List<Models.Student> lst = new List<Models.Student>();

            JavaScriptSerializer serializer = new JavaScriptSerializer();
            dynamic item = serializer.Deserialize<object>(v);
            var ClassId = item["ClassId"];
            var StudentName = item["StudentName"];
            var Gender = item["Gender"];
            var BirthDay = item["BirthDay"];

            lst = GetGridData(ClassId, StudentName, Gender, BirthDay);

            return this.Jsonp(lst);

        }

        public JsonpResult BindGridOnSearch(int ClassId, string StudentName, string Gender, string BirthDay)
        {

            List<Models.Student> lst = new List<Models.Student>();
            lst = GetGridData(ClassId, StudentName, Gender, BirthDay).ToList();

            return this.Jsonp(lst);

        }

        public IEnumerable<Models.Student> GetGridData(int ClassId, string StudentName, string Gender, string BirthDay)
        {
            //List<Models.Student> objCmp = new List<Models.Student>();
            students = GetDataStudent();
            List<Models.Student> listStudents = students;

           // var b = students.ToList()[1].BirthDay.ToString("dd-MM-yyyy");
            if (ClassId >= 0)
            {
                listStudents = students.ToList().Where(a => (a.ClassId == ClassId && a.StudentName.ToLower().Contains(StudentName.ToLower()) && a.Gender.ToString().ToLower().Contains(Gender) && a.BirthDay.ToString("dd/MM/yyyy").Contains(BirthDay))).ToList();

            }
            else
            {

                listStudents = students.ToList().Where(a => (a.StudentName.ToLower().Contains(StudentName.ToLower()) && a.Gender.ToString().ToLower().Contains(Gender) && a.BirthDay.ToString("dd/MM/yyyy").Contains(BirthDay))).ToList();
            }

            return listStudents.AsEnumerable();


        }

    }
}
