﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication3.Models
{
    public class Student
    {
        public int StudentID { set; get; }
        public string StudentName { set; get; }

        public int ClassId { set; get; }
        public bool Gender { set; get; }

        public DateTime BirthDay { set; get; }
    }
}