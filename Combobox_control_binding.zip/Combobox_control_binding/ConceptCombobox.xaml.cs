﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfConcept.Model.BOs;
using Telerik.Windows.Controls;

namespace WpfConcept.controls
{
    public partial class ConceptCombobox : UserControl
    {
        //private bool _IsNotEmpty;
        //public bool IsNotEmpty
        //{
        //    get { return _IsNotEmpty; }
        //    set
        //    {
        //        _IsNotEmpty = value;
        //        SetLabelValidValueDefault();
        //    }
        //}

        //public bool CheckValid()
        //{
        //    if (this._IsNotEmpty == false)
        //    {
        //        txtValidationLabel.Text = "";
        //        return true;
        //    }
        //    else
        //    {
        //        if ( (this.txtTextBox.Text == null || txtTextBox.SelectedItem == null || txtTextBox.SelectedValue == null))
        //        {
        //            txtValidationLabel.Text =  MessageConceppt.strNotEmpty;
        //            return false;
        //        }

        //        else if (this.txtTextBox.Text == "")
        //        {
        //            txtValidationLabel.Text = MessageConceppt.strNotEmpty;

        //            return false;
        //        }
        //        else if (this.txtTextBox.Text != "" && txtTextBox.SelectedValue != null && txtTextBox.SelectedItem != null)
        //        {
        //            txtValidationLabel.Text = "(*)";
        //            return true;
        //        }         
        //        else
        //        {
        //            txtValidationLabel.Text = "(*)";
        //            return true;
        //        }

        //    }
        //}

        //public void SetLabelValidValueDefault()
        //{
        //    if (_IsNotEmpty == true)
        //    {
        //        _ValidationLabelValue = "(*)";
        //        ValidationLabelValue = "(*)";
        //    }
        //    else
        //    {
        //        _ValidationLabelValue = "";
        //        ValidationLabelValue = "";
        //    }
        //    txtValidationLabel.Text = _ValidationLabelValue;
        //}

        private string _ValidationLabelValue;
        public string ValidationLabelValue
        {
            get { return _ValidationLabelValue; }
            set
            {
                _ValidationLabelValue = value;

            }
        }
        public static readonly DependencyProperty ValidationLabelValueProperty =
            DependencyProperty.Register("ValidationLabelValue", typeof(string),
              typeof(ConceptCombobox), new PropertyMetadata(null));

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            this.TxtTextBox.Text = "";
            this.TxtTextBox.SelectedItem = null;
            this.TxtTextBox.SelectedIndex = -1;
            this.TxtTextBox.Focus();
        }
        public void SetFocus()
        {
            this.TxtTextBox.Focus();
        }
        public Boolean IsEnabledConcept
        {
            get { return (Boolean)GetValue(IsEnabledConceptProperty); }
            set { SetValue(IsEnabledConceptProperty, value); }
        }

        public static readonly DependencyProperty IsEnabledConceptProperty =
            DependencyProperty.Register("IsEnabledConcept", typeof(bool),
              typeof(ConceptCombobox), new PropertyMetadata(null));

        private Visibility _VisibilityClearButton = Visibility.Visible;
        public Visibility VisibilityClearButton
        {
            get { return _VisibilityClearButton; }
            set
            {
                _VisibilityClearButton = value;
            }
        }
        public String Label
        {
            get { return (String)GetValue(LabelProperty); }
            set { SetValue(LabelProperty, value); }
        }

        public static readonly DependencyProperty LabelProperty =
            DependencyProperty.Register("Label", typeof(string),
              typeof(ConceptCombobox), new PropertyMetadata(""));

        public object Value
        {
            get { return (object)GetValue(ValueProperty); }
            set { SetValue(ValueProperty, value); }
        }

        public static readonly DependencyProperty ValueProperty =
            DependencyProperty.Register("Value", typeof(object),
              typeof(ConceptCombobox), new PropertyMetadata(null));

        public String Text
        {
            get { return (String)TxtTextBox.Text; }
            set { SetValue(TextProperty, value);
            }
        }

        public static readonly DependencyProperty TextProperty =
          DependencyProperty.Register("Text", typeof(string),
            typeof(ConceptCombobox), new PropertyMetadata(null));

        public Double WidthConcept
        {
            get { return (Double)GetValue(WidthConceptProperty); }
            set { SetValue(WidthConceptProperty, value); }
        }
        public static readonly DependencyProperty WidthConceptProperty =
            DependencyProperty.Register("WidthConcept", typeof(double),
              typeof(ConceptCombobox), new PropertyMetadata(null));
        public Double HeightConcept
        {
            get { return (Double)GetValue(HeightConceptProperty); }
            set { SetValue(HeightConceptProperty, value); }
        }
        public static readonly DependencyProperty HeightConceptProperty =
            DependencyProperty.Register("HeightConcept", typeof(double),
              typeof(ConceptCombobox), new PropertyMetadata(null));
        public Double FontSizeConcept
        {
            get { return (Double)GetValue(FontSizeConceptProperty); }
            set { SetValue(FontSizeConceptProperty, value); }
        }
        public static readonly DependencyProperty FontSizeConceptProperty =
            DependencyProperty.Register("FontSizeConcept", typeof(double),
              typeof(ConceptCombobox), new PropertyMetadata(null));

        public Brush ForegroundConcept
        {
            get { return (Brush)GetValue(ForegroundConceptProperty); }
            set { SetValue(ForegroundConceptProperty, value); }
        }
        public static readonly DependencyProperty ForegroundConceptProperty =
            DependencyProperty.Register("ForegroundConcept", typeof(Brush),
              typeof(ConceptCombobox), new PropertyMetadata(null));

        public Brush BackgroundConcept
        {
            get { return (Brush)GetValue(BackgroundConceptProperty); }
            set { SetValue(BackgroundConceptProperty, value); }
        }

        public static readonly DependencyProperty BackgroundConceptProperty =
            DependencyProperty.Register("BackgroundConcept", typeof(Brush),
              typeof(ConceptCombobox), new PropertyMetadata(null));

        public object ItemSourceConcept
        {
            get { return (object)GetValue(ItemSourceConceptProperty); }
            set { SetValue(ItemSourceConceptProperty, value); }
        }

        public static readonly DependencyProperty ItemSourceConceptProperty =
            DependencyProperty.Register("ItemSourceConcept", typeof(object),
              typeof(ConceptCombobox), new PropertyMetadata(null));

        public object SelectedValueConcept
        {
            get { return (object)GetValue(SelectedValueConceptProperty); }
            set { SetValue(SelectedValueConceptProperty, value);
            }
        }

        public static readonly DependencyProperty SelectedValueConceptProperty =
            DependencyProperty.Register("SelectedValueConcept", typeof(object),
              typeof(ConceptCombobox), new PropertyMetadata(null));

        public object SelectedItem
        {
            get { return (object)GetValue(SelectedItemProperty); }
            set
            {
                SetValue(SelectedItemProperty, value);
            }
        }

        public static readonly DependencyProperty SelectedItemProperty =
            DependencyProperty.Register("SelectedItem", typeof(object),
              typeof(ConceptCombobox), new PropertyMetadata(null));


        private string _DisplayMemberPath ;
        public string DisplayMemberPath
        {
            get { return _DisplayMemberPath; }
            set
            {
                this.TxtTextBox.DisplayMemberPath = value;
                _DisplayMemberPath = value;
            }
        }
        private string _SelectedValuePath;
        public string SelectedValuePath
        {
            get { return _SelectedValuePath; }
            set
            {
                TxtTextBox.SelectedValuePath = value;
                _SelectedValuePath = value;
            }
        }
        private PickerValue _GetValuePicker;
        public PickerValue GetValuePicker
        {
            get { return (PickerValue)GetValue(getValuePickerProperty);
                }
            set { SetValue(getValuePickerProperty, value);
                _GetValuePicker = value;
            }
        }
        public static readonly DependencyProperty getValuePickerProperty =
          DependencyProperty.Register("GetValuePicker", typeof(PickerValue),
            typeof(ConceptCombobox), new PropertyMetadata(null));

        public String SelectedItemName
        {
            get { return (String)GetValue(SelectedItemNameProperty); }
            set
            {
                SetValue(SelectedItemNameProperty, value);
            }
        }

        public static readonly DependencyProperty SelectedItemNameProperty =
          DependencyProperty.Register("SelectedItemName", typeof(string),
            typeof(ConceptCombobox), new PropertyMetadata(null));

        public String SelectedItemCode
        {
            get { return (String)GetValue(SelectedItemCodeProperty); }
            set
            {
                SetValue(SelectedItemCodeProperty, value);
            }
        }

        public static readonly DependencyProperty SelectedItemCodeProperty =
          DependencyProperty.Register("SelectedItemCode", typeof(string),
            typeof(ConceptCombobox), new PropertyMetadata(null));

        public System.Windows.Controls.Primitives.PlacementMode PopupPositionConcept
        {
            get {
                
                return (System.Windows.Controls.Primitives.PlacementMode)GetValue(PopupPositionConceptProperty); }
            set
            {
                SetValue(PopupPositionConceptProperty, value);


                ControlTemplate ct = this.TxtTextBox.Template;
                System.Windows.Controls.Primitives.Popup pop = ct.FindName("PART_Popup", this.TxtTextBox) as System.Windows.Controls.Primitives.Popup;
                pop.Placement = value;

            }
        }

        public static readonly DependencyProperty PopupPositionConceptProperty =
          DependencyProperty.Register("PopupPositionConcept", typeof(System.Windows.Controls.Primitives.PlacementMode),
            typeof(ConceptCombobox), new PropertyMetadata(null));

        public void ComboBoxSelectionChanged(object obj)
        {
            int selectIndex = -1;
            string code = "";
            string name = "";
            if (this.TxtTextBox.SelectedItem != null)
            {
                try
                {
                    SelectedValueConcept = this.TxtTextBox.SelectedValue;
                    SelectedItem = this.TxtTextBox.SelectedItem;
                    code = Convert.ToString(SelectedValueConcept);
                    name = TxtTextBox.Text;
                    selectIndex = this.TxtTextBox.SelectedIndex;
                    SelectedItemCode = code;
                    SelectedItemName = name;
                    GetValuePicker = new PickerValue { Name = name, strCode = code, Id = selectIndex };
                }
                catch
                {
                    GetValuePicker = new PickerValue { Name = "", strCode = "", Id = -1 };
                    SelectedItemName = Name;
                    SelectedItemCode = code;
                    SelectedValueConcept = null;
                }
            }
        }
        //void comboBoxSelectionChanged(object sender, SelectionChangedEventArgs e)
        //{
        //    int _SelectIndex = -1;
        //    var _strCode = "";
        //    var _text = "";
        //    //SetPopupPosition();
        //    // bool valid =  CheckValid();
        //    //if (valid == true)
        //    //{
        //        if (this.txtTextBox.SelectedItem != null)
        //        {
        //            try
        //            {
        //             SelectedValueConcept = this.txtTextBox.SelectedValue;
        //             SelectedItem = this.txtTextBox.SelectedItem;
        //            _strCode = Convert.ToString(SelectedValueConcept);
        //            _text = txtTextBox.Text;
        //            _SelectIndex = this.txtTextBox.SelectedIndex;
        //            SelectedItemCode = _strCode;
        //            SelectedItemName = _text;
        //            getValuePicker = new PickerValue { Name = _text, strCode = _strCode, Id= _SelectIndex };
        //                // { Code = _code, Name = _text, strCode = _strCode, Id = 0 };
        //            }
        //            catch
        //            {
        //            getValuePicker = new PickerValue { Name = "", strCode = "", Id=-1 };
        //            SelectedItemName = Name;
        //            SelectedItemCode = _strCode;
        //            SelectedValueConcept = null;
                      
        //            }
        //        }   
        //}

        public System.Windows.Controls.Primitives.Popup PopUpConcept;
        public void SetPopupPosition()
        {
            if (PopUpConcept != null)
            {
                if (PopUpConcept.Placement != PopupPositionConcept)
                {
                    PopUpConcept.Placement = PopupPositionConcept;
                }
            }
        }
        //public ICommand ClickDeleteCommand
        //{
        //    get { return (ICommand)GetValue(ClickDeleteCommandProperty); }
        //    set { SetValue(ClickDeleteCommandProperty, value); }
        //}

        //public static readonly DependencyProperty ClickDeleteCommandProperty =
        //    DependencyProperty.Register("ClickDeleteCommand", typeof(ICommand), typeof(ConceptCombobox), new PropertyMetadata(null));
        public ICommand SelectionCommandConcept
        {
            get
            {
                return (ICommand)GetValue(SelectionCommandConceptProperty);
            }
            set
            {
                SetValue(SelectionCommandConceptProperty, value);
            }
        }
        public static readonly DependencyProperty SelectionCommandConceptProperty =
        DependencyProperty.Register("SelectionCommandConcept", typeof(ICommand),
          typeof(ConceptCombobox), new PropertyMetadata(null));

        public void SetDefaultValue()
        {          
            IsEnabledConcept = true;
            TxtTextBox.IsEnabled = true;
            FontSizeConcept = FormatControl.DefaultFontSize;
            if (TxtTextBox.Width == 0 && WidthConcept == 0)        
            {
                TxtTextBox.Width = FormatControl.DefaultTextControlWidth;
            }
            if (TxtTextBox.Height == 0 && HeightConcept == 0)
            {
                TxtTextBox.Height = FormatControl.DefaultTextControlHeight;
            }
            ForegroundConcept = FormatControl.DefaultForegroundTextBox;
            BackgroundConcept = FormatControl.DefaultBackgroundTextBox;
        }
        public ConceptCombobox()
        {
            InitializeComponent();
           // SetLabelValidValueDefault();
            SetDefaultValue();
        }     
        private void Parent_Loaded(object sender, RoutedEventArgs e)
        {
            ControlTemplate conTemplate = this.TxtTextBox.Template;
            System.Windows.Controls.Primitives.Popup pop = conTemplate.FindName("PART_Popup", this.TxtTextBox) as System.Windows.Controls.Primitives.Popup;
            pop.Placement = PopupPositionConcept;
            PopUpConcept = pop;

            //if (this.ClickDeleteCommand == null)
            //{
            //    this.ClickDeleteCommand = new RoutedCommand();
            //    this.CommandBindings.Add(new CommandBinding(this.ClickDeleteCommand, this.ClearButton_Click));
            //}

            if (this.SelectionCommandConcept == null)
            {
               // this.SelectionCommandConcept = new RoutedCommand();
                this.SelectionCommandConcept = new DelegateCommand(this.ComboBoxSelectionChanged);
                //this.CommandBindings.Add(new CommandBinding(this.SelectionCommandConcept, this.comboBoxSelectionChanged1));
            }
        }
        private void TxtTextBox_DropDownOpened(object sender, EventArgs e)
        {
            SetPopupPosition();
        }

        private void TxtTextBox_GotFocus(object sender, RoutedEventArgs e)
        {

        }
        private void TxtTextBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
